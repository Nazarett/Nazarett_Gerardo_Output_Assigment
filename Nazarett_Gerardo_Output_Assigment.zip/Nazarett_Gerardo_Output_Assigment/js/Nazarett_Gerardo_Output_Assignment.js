console.log("Gerardo D. Nazarett")
console.log("C201506")
console.log("Data Infrastructers")
console.log("Creating Variables And Outputs")
console.log("Number Variable")

var age = 36;
var dayBorn = 30;
var monthBorn = 03;
var yearBorn = 1979;
console.log("This will let you know my age, day, month and year I was born");
console.log(age)
console.log(dayBorn);
console.log(monthBorn);
console.log(yearBorn);

//String Variable

var firstName = "Gerardo";
var lastName = "Nazarett";
var myJob = "I'm a UPS driver";
var militaryBackround = "I served in the United States Army for 4 years 1/2"
console.log("About me");
console.log(firstName);
console.log(lastName);
console.log(myJob)
console.log(militaryBackround)
//Boolen Vaiable

var UpsDriver = true;
var Janitor = false;
console.log("Not sure how this boolean variable works, all I know is that it is true or false");
console.log(UpsDriver)
console.log(Janitor)